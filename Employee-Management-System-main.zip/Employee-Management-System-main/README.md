# Employee-Management-System
Download and extraxt ZIP file to view the project.

### REQUIREMENTS ####
SOFTWARE REQUIREMENTS:- 
IDE with java JDK 21

MySQL Server, MySQL Workbench, MySQL Shell

All .jar files should be included as a external library i.e :-
1. MySQL-Connector-Java.jar
2. Jcalender-1.4.jar
3. rs2xml.jar
All source files in the same folder
